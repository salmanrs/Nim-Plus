# 🤖 راهنمای GitHub Actions برای نیم پلاس

این پروژه از GitHub Actions برای ساخت خودکار APK استفاده می‌کند!

## 🎯 چی اتفاق می‌افته؟

وقتی پروژه رو به GitHub آپلود می‌کنی، **خودکار**:
1. ✅ JDK 17 نصب می‌شه
2. ✅ Gradle setup می‌شه  
3. ✅ پروژه کامپایل می‌شه
4. ✅ APK ساخته می‌شه
5. ✅ APK برای دانلود آماده می‌شه

**همه چی خودکار!** شما فقط upload کنید! 🚀

---

## 📋 دو نوع Workflow داریم:

### 1️⃣ Build Workflow (خودکار)
- **فایل:** `.github/workflows/build.yml`
- **وقتی اجرا میشه:** هر push یا pull request
- **چی می‌کنه:** Debug و Release APK می‌سازه

### 2️⃣ Release Workflow (دستی)
- **فایل:** `.github/workflows/release.yml`
- **وقتی اجرا میشه:** وقتی tag می‌زنید یا دستی run می‌کنید
- **چی می‌کنه:** یک Release رسمی با APK می‌سازه

---

## 🚀 راهنمای قدم به قدم

### گام 1: آپلود به GitHub

1. به GitHub برید و login کنید
2. Repository جدید بسازید (اسم: `nim-plus`)
3. همه فایل‌ها رو آپلود کنید

```bash
# یا با Git:
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/nim-plus.git
git push -u origin main
```

### گام 2: فعال‌سازی Actions

1. به تب **Actions** برید
2. اگه پیغامی داد، روی **"I understand, enable them"** کلیک کنید

✅ حالا Actions فعال شد!

### گام 3: صبر کنید تا Build بشه

1. Workflow خودکار شروع می‌شه
2. به تب **Actions** برید
3. آخرین workflow رو ببینید (🟡 زرد → ⏳ در حال اجرا)
4. صبر کنید تا سبز بشه (✅ موفق)

⏱️ **زمان:** حدود 5-10 دقیقه

### گام 4: دانلود APK

وقتی workflow تموم شد:

1. روی اسم workflow کلیک کنید
2. پایین صفحه **Artifacts** رو ببینید
3. فایل‌های زیر رو دانلود کنید:
   - ✅ `nim-plus-debug-apk` - APK اصلی
   - 📄 `build-info` - اطلاعات build

4. فایل zip رو extract کنید
5. `app-debug.apk` آماده نصب است! 🎉

---

## 🎊 ساخت Release رسمی

می‌خواید یک نسخه رسمی منتشر کنید؟

### روش 1: با Tag

```bash
git tag -a v1.0.0 -m "نسخه اول"
git push origin v1.0.0
```

### روش 2: دستی از GitHub

1. تب **Actions** → **Create Release**
2. **Run workflow** کلیک کنید
3. نسخه رو وارد کنید (مثلاً: `1.0.0`)
4. **Run workflow** بزنید

✅ یک Release کامل با APK ساخته می‌شه!

---

## 📊 نظارت بر Build ها

### مشاهده لاگ‌ها:

1. Actions → workflow مورد نظر
2. روی هر مرحله کلیک کنید
3. لاگ‌های کامل رو ببینید

### اگه Build fail شد:

1. لاگ‌ها رو بخونید
2. معمولاً مشکلات رایج:
   - ❌ gradlew executable نیست → خودکار حل میشه
   - ❌ V2Ray Core نیست → اختیاری برای تست
   - ❌ Dependency مشکل داره → در Issue گزارش بدید

---

## 🔧 تنظیمات پیشرفته

### تغییر نسخه Java:

در `build.yml` خط 17:
```yaml
java-version: '17'  # می‌تونید عوض کنید
```

### تغییر Gradle settings:

در `build.yml` خط 39-40:
```yaml
run: ./gradlew assembleDebug --stacktrace --no-daemon
# اضافه کردن flag های دیگه
```

### کش کردن بیشتر:

خطوط 25-33 رو ببینید - Gradle cache فعاله.

---

## 📱 نصب APK روی گوشی

بعد از دانلود:

1. فایل `app-debug.apk` رو به گوشی منتقل کنید
2. روی فایل کلیک کنید
3. اگه پیغام داد: **Settings → Security → Unknown sources** فعال کنید
4. دوباره روی APK کلیک کنید
5. **Install** بزنید

✅ نیم پلاس نصب شد! 🎉

---

## 🐛 مشکلات رایج

### Actions اجرا نمیشه

**راه حل:**
```
Settings → Actions → General
→ Allow all actions and reusable workflows
→ Save
```

### Workflow در queue مونده

**دلیل:** GitHub Actions busy هست
**راه حل:** صبر کنید (معمولاً چند دقیقه)

### Build fail میشه

**دلایل احتمالی:**
1. ❌ Gradle wrapper مشکل داره → خودکار حل میشه
2. ❌ Dependency download نمیشه → دوباره run کنید
3. ❌ Out of memory → معمولاً نمیشه!

**راه حل:** دوباره run کنید:
```
Actions → Failed workflow → Re-run jobs
```

### Artifact دانلود نمیشه

**دلایل:**
- Workflow هنوز تموم نشده (صبر کنید)
- Workflow fail شده (لاگ‌ها رو بخونید)
- Login نکردید (Login کنید)

---

## 💡 نکات مهم

### ✅ انجام بدید:
- Workflow ها رو توی repository نگه دارید
- لاگ‌ها رو برای debug بخونید
- APK های قدیمی رو پاک کنید (Artifacts 30 روز نگه داشته میشن)

### ❌ انجام ندید:
- Secret ها رو commit نکنید!
- API key یا token رو hard-code نکنید
- بیش از حد workflow run نکنید (محدودیت داره)

---

## 📚 منابع بیشتر

- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [Android Build Actions](https://github.com/marketplace/actions/android-build)
- [Upload Artifact Action](https://github.com/actions/upload-artifact)

---

## 🎉 تمام!

حالا GitHub Actions شما:
- ✅ خودکار APK می‌سازه
- ✅ قابل دانلود می‌کنه
- ✅ Release هم می‌تونه بسازه

**هر سوالی داشتید، بپرسید!** 😊

---

## 🆘 کمک بیشتر

اگه مشکل داشتید:
- 📖 [EASIEST-WAY.md](../EASIEST-WAY.md) رو بخونید
- 📖 [HOW-TO-GET-APK.md](../HOW-TO-GET-APK.md) رو ببینید
- 💬 در [Discussions](https://github.com/USERNAME/nim-plus/discussions) بپرسید
- 📧 ایمیل بزنید: support@nimplus.app

**موفق باشید!** 🚀
