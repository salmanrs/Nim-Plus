#!/bin/bash

# Script to build APK using Docker
# Usage: ./docker-build.sh

echo "🚀 Building Nim Plus APK using Docker..."
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed!"
    echo "Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

echo "✅ Docker found"
echo ""

# Build Docker image
echo "📦 Building Docker image (this may take a few minutes)..."
docker build -t nim-plus-builder .

if [ $? -ne 0 ]; then
    echo "❌ Failed to build Docker image"
    exit 1
fi

echo "✅ Docker image built successfully"
echo ""

# Run container and build APK
echo "🔨 Building APK..."
docker run --rm -v $(pwd)/app/build:/app/app/build nim-plus-builder

if [ $? -ne 0 ]; then
    echo "❌ Failed to build APK"
    exit 1
fi

echo ""
echo "✅ APK built successfully!"
echo ""
echo "📱 Your APK files are located at:"
echo "   Debug: app/build/outputs/apk/debug/app-debug.apk"
echo "   Release: app/build/outputs/apk/release/app-release.apk"
echo ""
echo "🎉 Done!"
