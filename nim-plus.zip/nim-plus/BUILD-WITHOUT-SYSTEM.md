# 📱 راهنمای ساخت APK بدون سیستم شخصی

## 🎯 روش 1: استفاده از GitHub Actions (پیشنهادی و رایگان)

این روش کاملاً **رایگان** و **خودکار** است!

### مراحل:

#### گام 1: ساخت اکانت GitHub
1. به [github.com](https://github.com) برید
2. یک اکانت رایگان بسازید

#### گام 2: آپلود پروژه
1. Repository جدید بسازید (اسمش رو بذارید `nim-plus`)
2. فایل `nim-plus-project.tar.gz` رو extract کنید
3. فایل‌ها رو به GitHub آپلود کنید

**روش آسان (از طریق وب):**
- در صفحه repository، روی "Upload files" کلیک کنید
- تمام فایل‌های extract شده رو drag & drop کنید
- "Commit changes" بزنید

**روش حرفه‌ای (با Git):**
```bash
# اگر Git نصب دارید
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/nim-plus.git
git push -u origin main
```

#### گام 3: صبر کنید تا Build بشه
- GitHub Actions خودکار شروع می‌شه
- به تب "Actions" برید
- ببینید build در حال انجام است (حدود 5-10 دقیقه)

#### گام 4: دانلود APK
وقتی build تموم شد:
1. به تب "Actions" برید
2. روی آخرین workflow کلیک کنید
3. پایین صفحه "Artifacts" رو ببینید
4. `nim-plus-debug.apk` یا `nim-plus-release.apk` رو دانلود کنید

✅ **تمام!** حالا APK آماده نصب است!

---

## 🎯 روش 2: استفاده از Replit (آنلاین و رایگان)

### مراحل:

1. به [replit.com](https://replit.com) برید
2. اکانت بسازید (رایگان)
3. یک Repl جدید بسازید (نوع: Java)
4. فایل‌های پروژه رو آپلود کنید
5. در Terminal بزنید:
```bash
# نصب Android SDK
wget https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip
unzip commandlinetools-linux-9477386_latest.zip
export ANDROID_HOME=$HOME/android-sdk
./cmdline-tools/bin/sdkmanager --sdk_root=$ANDROID_HOME "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# Build کردن
./gradlew assembleDebug
```

---

## 🎯 روش 3: استفاده از Gitpod (آنلاین)

[Gitpod](https://gitpod.io) یک محیط توسعه آنلاین رایگان است.

1. Repository خود را در GitHub بسازید
2. به آدرس `https://gitpod.io/#https://github.com/USERNAME/nim-plus` برید
3. منتظر بمانید تا محیط آماده شود
4. در Terminal:
```bash
./gradlew assembleDebug
```

---

## 🎯 روش 4: از دوستان کمک بگیرید

اگر دوستی Android Studio داره:

### فایل‌هایی که نیاز داره:
1. ✅ پروژه کامل (که دارید)
2. ✅ Android Studio
3. ✅ 15 دقیقه وقت

### مراحل برای دوستتون:
1. پروژه رو Extract کنه
2. در Android Studio باز کنه
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`
4. منتظر بمونه تا Build تموم شه
5. APK در `app/build/outputs/apk/debug/` هست

---

## 🎯 روش 5: استفاده از سرویس‌های Build آنلاین

### AppCenter (Microsoft)
- رایگان برای پروژه‌های Open Source
- Build خودکار APK
- [appcenter.ms](https://appcenter.ms)

### Bitrise
- رایگان تا 200 build در ماه
- [bitrise.io](https://bitrise.io)

### CircleCI
- رایگان برای پروژه‌های Public
- [circleci.com](https://circleci.com)

---

## 📝 نکات مهم

### ⚠️ قبل از Build:

1. **V2Ray Core اضافه کنید**:
   - دانلود کنید: [AndroidLibV2rayLite Releases](https://github.com/2dust/AndroidLibV2rayLite/releases)
   - فایل `libv2ray.aar` رو در `app/libs/` بذارید
   - در `app/build.gradle.kts` uncomment کنید:
   ```kotlin
   implementation(files("libs/libv2ray.aar"))
   ```

2. **امضای APK** (برای Release):
   - Keystore بسازید یا از یکی استفاده کنید
   - در `keystore.properties` تنظیم کنید

### 🔍 چک کردن APK:

بعد از build:
```bash
# بررسی اطلاعات APK
aapt dump badging app-debug.apk

# نصب روی دستگاه
adb install app-debug.apk
```

---

## 🚀 پیشنهاد من: GitHub Actions

**چرا بهترینه:**
- ✅ کاملاً رایگان
- ✅ خودکار
- ✅ نیازی به نصب چیزی نیست
- ✅ همیشه در دسترس
- ✅ APK رو نگه می‌داره

**فقط کافیه:**
1. اکانت GitHub بسازید (2 دقیقه)
2. پروژه رو آپلود کنید (5 دقیقه)
3. صبر کنید تا Build بشه (10 دقیقه)
4. APK رو دانلود کنید (1 دقیقه)

**جمع: 18 دقیقه تا داشتن APK!** 🎉

---

## 💡 مشکل دارید؟

اگر تو هر کدوم از این روش‌ها مشکل داشتید:

1. 📧 **ایمیل بزنید**: support@nimplus.app
2. 💬 **در GitHub Issue بپرسید**
3. 🔍 **ویدیوهای آموزشی YouTube** ببینید:
   - "How to build Android APK with GitHub Actions"
   - "Android build online"

---

## ✅ چک‌لیست

قبل از شروع مطمئن بشید:
- [ ] اکانت GitHub دارید
- [ ] پروژه رو extract کردید
- [ ] فایل V2Ray Core رو دانلود کردید (اختیاری برای تست)
- [ ] صبر و حوصله دارید! 😊

---

**موفق باشید!** 🚀

نیاز به کمک بیشتر دارید؟ بهم بگید کدوم روش رو انتخاب کردید و کجا گیر کردید.
