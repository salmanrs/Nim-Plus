# نیم پلاس (Nim Plus) 🚀

<p align="center">
  <img src="app/src/main/res/mipmap-xxxhdpi/ic_launcher.png" alt="Nim Plus Logo" width="120" height="120">
</p>

<p align="center">
  <strong>کلاینت VPN قدرتمند و امن برای اندروید</strong>
</p>

<p align="center">
  <a href="#ویژگی‌ها">ویژگی‌ها</a> •
  <a href="#نصب">نصب</a> •
  <a href="#استفاده">استفاده</a> •
  <a href="#ساخت">ساخت</a> •
  <a href="#مشارکت">مشارکت</a> •
  <a href="#لایسنس">لایسنس</a>
</p>

---

## 📱 درباره نیم پلاس

نیم پلاس یک کلاینت VPN متن‌باز و رایگان برای اندروید است که با تمرکز بر امنیت، سرعت و سادگی استفاده طراحی شده است.

## ✨ ویژگی‌ها

- 🔒 **امنیت بالا**: رمزنگاری قدرتمند و پروتکل‌های امن
- ⚡ **سرعت بالا**: بهینه‌سازی شده برای بهترین عملکرد
- 🎨 **رابط کاربری مدرن**: طراحی Material Design 3
- 🌐 **چند پروتکل**: پشتیبانی از VMess، VLESS، Shadowsocks، Trojan و ...
- 📊 **نمایش آمار**: مصرف ترافیک و سرعت اتصال به صورت لحظه‌ای
- 🔄 **اتصال خودکار**: اتصال مجدد خودکار در صورت قطع شدن
- 🌙 **حالت شب**: پشتیبانی کامل از تم تاریک و روشن
- 🇮🇷 **پشتیبانی از فارسی**: رابط کاملاً فارسی
- 🆓 **رایگان و متن‌باز**: کاملاً رایگان و بدون تبلیغات

## 📥 نصب

### از طریق APK
1. فایل APK را از [صفحه Releases](https://github.com/yourusername/nim-plus/releases) دانلود کنید
2. فایل را روی گوشی خود نصب کنید
3. مجوزهای لازم را بپذیرید و از برنامه لذت ببرید!

### ساخت از سورس
نیازمندی‌ها:
- Android Studio Hedgehog | 2023.1.1 یا جدیدتر
- JDK 17
- Android SDK 34
- Gradle 8.2+

## 🚀 استفاده

1. **افزودن کانفیگ**: 
   - با کلیک روی دکمه ➕، کانفیگ جدید اضافه کنید
   - از طریق QR Code، لینک یا وارد کردن دستی

2. **اتصال**:
   - کانفیگ مورد نظر را انتخاب کنید
   - روی دکمه اتصال کلیک کنید
   - منتظر برقراری اتصال بمانید

3. **مدیریت کانفیگ‌ها**:
   - ویرایش، حذف و تست کانفیگ‌ها
   - ایمپورت و اکسپورت کانفیگ‌ها

## 🛠️ ساخت

```bash
# کلون کردن مخزن
git clone https://github.com/yourusername/nim-plus.git
cd nim-plus

# ساخت نسخه Debug
./gradlew assembleDebug

# ساخت نسخه Release
./gradlew assembleRelease

# نصب بر روی دستگاه متصل
./gradlew installDebug
```

## 🏗️ معماری

این پروژه از معماری **MVVM** (Model-View-ViewModel) استفاده می‌کند:

```
├── app/
│   ├── src/main/
│   │   ├── java/com/nimplus/
│   │   │   ├── data/          # لایه داده
│   │   │   ├── ui/            # رابط کاربری
│   │   │   ├── viewmodel/     # ViewModel ها
│   │   │   ├── service/       # سرویس VPN
│   │   │   └── utils/         # کمکی‌ها
│   │   ├── res/               # منابع
│   │   └── AndroidManifest.xml
```

## 📚 تکنولوژی‌های استفاده شده

- **Kotlin**: زبان برنامه‌نویسی اصلی
- **Jetpack Compose**: رابط کاربری مدرن
- **Room**: پایگاه داده محلی
- **Hilt**: Dependency Injection
- **Coroutines & Flow**: برنامه‌نویسی ناهمزمان
- **V2Ray Core**: هسته VPN
- **Material Design 3**: طراحی رابط کاربری

## 🤝 مشارکت

مشارکت شما در بهبود نیم پلاس بسیار ارزشمند است!

1. پروژه را Fork کنید
2. یک Branch جدید بسازید (`git checkout -b feature/AmazingFeature`)
3. تغییرات خود را Commit کنید (`git commit -m 'Add some AmazingFeature'`)
4. به Branch خود Push کنید (`git push origin feature/AmazingFeature`)
5. یک Pull Request باز کنید

## 📄 لایسنس

این پروژه تحت لایسنس GPL-3.0 منتشر شده است - فایل [LICENSE](LICENSE) را برای جزئیات بیشتر مطالعه کنید.

## 🙏 تشکر

- [V2Ray](https://www.v2fly.org/) - هسته VPN
- [Material Design](https://m3.material.io/) - راهنمای طراحی
- تمام مشارکت‌کنندگان که این پروژه را بهتر کرده‌اند

## 📞 تماس و پشتیبانی

- 🐛 گزارش باگ: [Issues](https://github.com/yourusername/nim-plus/issues)
- 💡 پیشنهادات: [Discussions](https://github.com/yourusername/nim-plus/discussions)
- 📧 ایمیل: support@nimplus.app

---

<p align="center">
  ساخته شده با ❤️ در ایران
</p>
