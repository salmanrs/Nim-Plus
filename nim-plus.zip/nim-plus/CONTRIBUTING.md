# راهنمای مشارکت در نیم پلاس

از اینکه می‌خواهید در توسعه نیم پلاس مشارکت کنید متشکریم! 🎉

## چطور می‌توانم کمک کنم؟

راه‌های مختلفی برای مشارکت وجود دارد:

### 1. گزارش باگ 🐛
اگر باگی پیدا کردید:
- ابتدا [Issues](https://github.com/yourusername/nim-plus/issues) را جستجو کنید
- اگر گزارش نشده، یک Issue جدید با برچسب `bug` بسازید
- اطلاعات زیر را شامل شوید:
  - شرح واضح مشکل
  - مراحل بازتولید باگ
  - رفتار مورد انتظار
  - اسکرین‌شات (در صورت امکان)
  - مشخصات دستگاه و نسخه اندروید
  - لاگ‌های مربوطه

### 2. پیشنهاد قابلیت جدید 💡
ایده‌ای برای بهبود دارید؟
- یک Issue با برچسب `enhancement` بسازید
- توضیح دهید چرا این قابلیت مفید است
- نحوه پیاده‌سازی پیشنهادی خود را شرح دهید

### 3. بهبود مستندات 📚
- اصلاح غلط‌های املایی
- افزودن مثال‌های بیشتر
- بهبود توضیحات موجود
- ترجمه به زبان‌های دیگر

### 4. نوشتن کد 💻
- باگ‌ها را رفع کنید
- قابلیت‌های جدید اضافه کنید
- عملکرد را بهینه کنید
- تست بنویسید

## فرآیند مشارکت

### 1. Fork کردن پروژه
```bash
# روی دکمه Fork در GitHub کلیک کنید
# سپس repository خود را کلون کنید
git clone https://github.com/YOUR_USERNAME/nim-plus.git
cd nim-plus
```

### 2. ساخت برنچ جدید
```bash
# برای باگ
git checkout -b fix/issue-name

# برای قابلیت جدید
git checkout -b feature/feature-name

# برای مستندات
git checkout -b docs/what-you-are-documenting
```

### 3. انجام تغییرات
- کد خود را بنویسید
- از استانداردهای کدنویسی پیروی کنید (پایین توضیح داده شده)
- تست‌های لازم را اضافه کنید

### 4. کامیت کردن
```bash
git add .
git commit -m "feat: add new feature X"
```

#### قالب پیام کامیت
از قالب [Conventional Commits](https://www.conventionalcommits.org/) استفاده کنید:

```
<type>: <description>

[optional body]

[optional footer]
```

انواع:
- `feat`: قابلیت جدید
- `fix`: رفع باگ
- `docs`: تغییرات مستندات
- `style`: فرمت‌بندی، نقطه‌گذاری، و غیره
- `refactor`: بازنویسی کد
- `test`: افزودن تست
- `chore`: تغییرات build یا ابزارها

مثال‌ها:
```
feat: add dark mode support
fix: resolve crash on connection
docs: update installation guide
refactor: improve connection logic
```

### 5. Push کردن
```bash
git push origin your-branch-name
```

### 6. ساخت Pull Request
- به repository اصلی بروید
- روی "New Pull Request" کلیک کنید
- برنچ خود را انتخاب کنید
- توضیحات کامل بدهید:
  - چه تغییراتی انجام شده
  - چرا این تغییرات لازم هستند
  - چطور تست کرده‌اید
  - اسکرین‌شات (برای UI)

## استانداردهای کدنویسی

### Kotlin Style Guide
- از [Kotlin Coding Conventions](https://kotlinlang.org/docs/coding-conventions.html) پیروی کنید
- از ktlint برای فرمت‌بندی استفاده کنید

```bash
./gradlew ktlintFormat
```

### معماری
- از معماری MVVM استفاده کنید
- از Hilt برای Dependency Injection استفاده کنید
- از Kotlin Coroutines برای عملیات async استفاده کنید
- از Jetpack Compose برای UI استفاده کنید

### نام‌گذاری
- **کلاس‌ها**: PascalCase (مثال: `VpnService`)
- **متغیرها/توابع**: camelCase (مثال: `connectToServer`)
- **ثابت‌ها**: UPPER_SNAKE_CASE (مثال: `MAX_RETRY_COUNT`)
- **فایل‌های resource**: snake_case (مثال: `activity_main.xml`)

### کامنت‌گذاری
- کد را خودتوضیح‌دهنده بنویسید
- فقط منطق پیچیده را کامنت کنید
- از KDoc برای توابع public استفاده کنید

```kotlin
/**
 * اتصال به سرور VPN را برقرار می‌کند
 *
 * @param config پیکربندی VPN
 * @return true در صورت موفقیت
 */
fun connect(config: VpnConfig): Boolean {
    // پیاده‌سازی
}
```

### تست
- برای logic مهم Unit Test بنویسید
- UI Test برای جریان‌های اصلی بنویسید

```bash
# اجرای تست‌ها
./gradlew test
./gradlew connectedAndroidTest
```

## کد رفتاری

### احترام متقابل
- با احترام با دیگران برخورد کنید
- از زبان توهین‌آمیز خودداری کنید
- به نظرات مخالف احترام بگذارید
- سازنده باشید

### تعهد
- Pull Request های خود را پیگیری کنید
- به بازخوردها پاسخ دهید
- تست کنید قبل از ارسال

### کیفیت
- کد تمیز بنویسید
- تست کامل انجام دهید
- مستندات را به‌روز کنید

## سوالات متداول

### چطور شروع کنم؟
1. Issues را برای مسائل مناسب مبتدی‌ها (`good first issue`) بررسی کنید
2. در Discussion سوال بپرسید
3. راهنمای نصب را دنبال کنید

### چقدر طول می‌کشد تا PR من بررسی شود؟
معمولاً طی 3-7 روز. اگر بیشتر طول کشید، یادآوری کنید.

### PR من رد شد، چرا؟
دلایل معمول:
- تست‌ها fail می‌کنند
- رعایت استانداردها نشده
- تغییرات با اهداف پروژه همخوانی ندارند
- نیاز به بازنگری دارد

### می‌توانم روی چند Issue همزمان کار کنم؟
بهتر است ابتدا یک مورد را کامل کنید.

## منابع مفید

- [Kotlin Style Guide](https://kotlinlang.org/docs/coding-conventions.html)
- [Android Development Best Practices](https://developer.android.com/topic/best-practices)
- [Jetpack Compose Guidelines](https://developer.android.com/jetpack/compose/mental-model)
- [Git Best Practices](https://git-scm.com/book/en/v2)

## تماس با ما

- **Telegram**: @nimplus
- **Email**: contribute@nimplus.app
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/nim-plus/discussions)

---

با تشکر از مشارکت شما! هر کمکی، کوچک یا بزرگ، ارزشمند است. ❤️
