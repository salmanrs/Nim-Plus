# راهنمای نصب و کامپایل نیم پلاس

## پیش‌نیازها

قبل از شروع، اطمینان حاصل کنید که موارد زیر را نصب کرده‌اید:

### 1. نصب JDK 17
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install openjdk-17-jdk

# macOS (با Homebrew)
brew install openjdk@17

# Windows
# از https://adoptium.net دانلود و نصب کنید
```

### 2. نصب Android Studio
- از [developer.android.com](https://developer.android.com/studio) دانلود کنید
- نصب کنید و SDK های لازم را دانلود کنید:
  - Android SDK Platform 34
  - Android SDK Build-Tools
  - Android SDK Platform-Tools

### 3. تنظیم متغیرهای محیطی
```bash
# Linux/macOS - اضافه کنید به ~/.bashrc یا ~/.zshrc
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools

# Windows - در Environment Variables
ANDROID_HOME=C:\Users\YourUsername\AppData\Local\Android\Sdk
```

## کلون کردن پروژه

```bash
git clone https://github.com/yourusername/nim-plus.git
cd nim-plus
```

## نکات مهم قبل از کامپایل

### 1. افزودن V2Ray Core
این پروژه برای عملکرد کامل نیاز به V2Ray Core دارد. برای افزودن آن:

```bash
# دایرکتوری libs را بسازید
mkdir -p app/libs

# فایل libv2ray.aar را دانلود کنید
# از https://github.com/2dust/AndroidLibV2rayLite/releases
# و در app/libs قرار دهید
```

سپس در `app/build.gradle.kts` خط زیر را از حالت کامنت خارج کنید:
```kotlin
implementation(files("libs/libv2ray.aar"))
```

### 2. امضای اپلیکیشن (برای نسخه Release)
برای ساخت نسخه Release، یک keystore بسازید:

```bash
keytool -genkey -v -keystore nim-plus.keystore -alias nim-plus -keyalg RSA -keysize 2048 -validity 10000
```

سپس فایل `keystore.properties` در ریشه پروژه بسازید:
```properties
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=nim-plus
storeFile=nim-plus.keystore
```

## کامپایل پروژه

### روش 1: استفاده از خط فرمان

```bash
# نصب Dependencies
./gradlew clean

# کامپایل نسخه Debug
./gradlew assembleDebug

# کامپایل نسخه Release
./gradlew assembleRelease

# نصب بر روی دستگاه متصل
./gradlew installDebug
```

فایل APK در مسیر زیر قرار می‌گیرد:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

### روش 2: استفاده از Android Studio

1. Android Studio را باز کنید
2. `File` > `Open` را انتخاب کنید
3. پوشه پروژه `nim-plus` را انتخاب کنید
4. صبر کنید تا Gradle sync انجام شود
5. از منوی `Build` گزینه `Build Bundle(s) / APK(s)` > `Build APK(s)` را انتخاب کنید

## اجرای برنامه

### روش 1: استفاده از Emulator
1. در Android Studio، AVD Manager را باز کنید
2. یک دستگاه مجازی بسازید (API 21 یا بالاتر)
3. دستگاه را اجرا کنید
4. دکمه Run (▶️) را کلیک کنید

### روش 2: استفاده از دستگاه واقعی
1. USB Debugging را در گوشی فعال کنید:
   - `Settings` > `About Phone` > 7 بار روی `Build Number` ضربه بزنید
   - به `Settings` > `Developer Options` بروید
   - `USB Debugging` را فعال کنید
2. گوشی را به کامپیوتر متصل کنید
3. اجازه debugging را بپذیرید
4. در Android Studio دکمه Run را بزنید

## رفع مشکلات رایج

### خطای "SDK location not found"
```bash
# ساخت فایل local.properties در ریشه پروژه
echo "sdk.dir=/path/to/your/Android/Sdk" > local.properties
```

### خطای "Java version"
مطمئن شوید که JDK 17 نصب شده و در PATH قرار دارد:
```bash
java -version
# باید Java 17 را نشان دهد
```

### خطای Gradle
Cache را پاک کنید:
```bash
./gradlew clean
./gradlew --stop
rm -rf .gradle
./gradlew assembleDebug
```

### خطای "Failed to resolve"
اینترنت خود را بررسی کنید و دوباره sync کنید:
```bash
./gradlew --refresh-dependencies
```

## توسعه و مشارکت

### ساختار پروژه
```
nim-plus/
├── app/
│   ├── src/main/
│   │   ├── java/com/nimplus/
│   │   │   ├── data/          # مدل‌های داده و دیتابیس
│   │   │   ├── di/            # Dependency Injection
│   │   │   ├── service/       # سرویس VPN
│   │   │   ├── ui/            # رابط کاربری Compose
│   │   │   └── viewmodel/     # ViewModel ها
│   │   ├── res/               # منابع (layouts, strings, etc.)
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── gradle/
└── build.gradle.kts
```

### اضافه کردن قابلیت جدید
1. برنچ جدید بسازید: `git checkout -b feature/new-feature`
2. تغییرات را اعمال کنید
3. کامیت کنید: `git commit -m "Add new feature"`
4. Push کنید: `git push origin feature/new-feature`
5. Pull Request بسازید

## منابع مفید

- [مستندات Android](https://developer.android.com/docs)
- [Jetpack Compose](https://developer.android.com/jetpack/compose)
- [V2Ray Documentation](https://www.v2fly.org/)
- [Kotlin Documentation](https://kotlinlang.org/docs/home.html)

## پشتیبانی

اگر با مشکلی مواجه شدید:
1. [Issues](https://github.com/yourusername/nim-plus/issues) را بررسی کنید
2. اگر مشکل شما گزارش نشده، یک Issue جدید بسازید
3. در [Discussions](https://github.com/yourusername/nim-plus/discussions) سوال بپرسید

---

موفق باشید! 🚀
