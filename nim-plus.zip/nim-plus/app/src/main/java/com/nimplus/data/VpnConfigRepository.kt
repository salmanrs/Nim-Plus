package com.nimplus.data

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VpnConfigRepository @Inject constructor(
    private val vpnConfigDao: VpnConfigDao
) {
    val allConfigs: Flow<List<VpnConfig>> = vpnConfigDao.getAllConfigs()
    
    suspend fun getConfigById(id: Long): VpnConfig? {
        return vpnConfigDao.getConfigById(id)
    }
    
    suspend fun getActiveConfig(): VpnConfig? {
        return vpnConfigDao.getActiveConfig()
    }
    
    suspend fun insertConfig(config: VpnConfig): Long {
        return vpnConfigDao.insertConfig(config)
    }
    
    suspend fun insertConfigs(configs: List<VpnConfig>) {
        vpnConfigDao.insertConfigs(configs)
    }
    
    suspend fun updateConfig(config: VpnConfig) {
        vpnConfigDao.updateConfig(config)
    }
    
    suspend fun deleteConfig(config: VpnConfig) {
        vpnConfigDao.deleteConfig(config)
    }
    
    suspend fun deleteConfigById(id: Long) {
        vpnConfigDao.deleteConfigById(id)
    }
    
    suspend fun setActiveConfig(id: Long) {
        vpnConfigDao.deactivateAllConfigs()
        vpnConfigDao.setActiveConfig(id)
    }
    
    suspend fun updateTraffic(id: Long, upload: Long, download: Long) {
        vpnConfigDao.updateTraffic(id, upload, download)
    }
    
    suspend fun updateLastConnected(id: Long) {
        vpnConfigDao.updateLastConnected(id, System.currentTimeMillis())
    }
}
