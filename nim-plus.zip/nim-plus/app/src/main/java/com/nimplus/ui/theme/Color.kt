package com.nimplus.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom Colors for Nim Plus
val Primary = Color(0xFF6366f1)
val PrimaryVariant = Color(0xFF4f46e5)
val Secondary = Color(0xFF8b5cf6)
val Accent = Color(0xFF10b981)
val Success = Color(0xFF10b981)
val Warning = Color(0xFFf59e0b)
val Error = Color(0xFFef4444)
val Info = Color(0xFF06b6d4)
