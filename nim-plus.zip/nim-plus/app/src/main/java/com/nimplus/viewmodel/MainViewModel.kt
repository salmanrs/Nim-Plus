package com.nimplus.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nimplus.data.ConnectionState
import com.nimplus.data.VpnConfig
import com.nimplus.data.VpnConfigRepository
import com.nimplus.service.VpnService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    application: Application,
    private val repository: VpnConfigRepository
) : AndroidViewModel(application) {
    
    private val _connectionState = MutableStateFlow(ConnectionState())
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()
    
    val allConfigs = repository.allConfigs
    
    private val _selectedConfig = MutableStateFlow<VpnConfig?>(null)
    val selectedConfig: StateFlow<VpnConfig?> = _selectedConfig.asStateFlow()
    
    init {
        loadActiveConfig()
    }
    
    private fun loadActiveConfig() {
        viewModelScope.launch {
            val activeConfig = repository.getActiveConfig()
            _selectedConfig.value = activeConfig
        }
    }
    
    fun selectConfig(config: VpnConfig) {
        _selectedConfig.value = config
        viewModelScope.launch {
            repository.setActiveConfig(config.id)
        }
    }
    
    fun connect() {
        val config = _selectedConfig.value ?: return
        
        val intent = Intent(getApplication(), VpnService::class.java).apply {
            action = VpnService.ACTION_CONNECT
            putExtra(VpnService.EXTRA_CONFIG, config)
        }
        
        getApplication<Application>().startService(intent)
        
        _connectionState.value = _connectionState.value.copy(
            isConnected = true,
            currentConfig = config
        )
        
        viewModelScope.launch {
            repository.updateLastConnected(config.id)
        }
    }
    
    fun disconnect() {
        val intent = Intent(getApplication(), VpnService::class.java).apply {
            action = VpnService.ACTION_DISCONNECT
        }
        
        getApplication<Application>().startService(intent)
        
        _connectionState.value = ConnectionState()
    }
    
    fun addConfig(config: VpnConfig) {
        viewModelScope.launch {
            repository.insertConfig(config)
        }
    }
    
    fun updateConfig(config: VpnConfig) {
        viewModelScope.launch {
            repository.updateConfig(config)
        }
    }
    
    fun deleteConfig(config: VpnConfig) {
        viewModelScope.launch {
            repository.deleteConfig(config)
            if (_selectedConfig.value?.id == config.id) {
                _selectedConfig.value = null
            }
        }
    }
    
    fun importConfigFromUri(uri: String) {
        viewModelScope.launch {
            try {
                // Parse config URI (vmess://, vless://, ss://, etc.)
                val config = parseConfigUri(uri)
                repository.insertConfig(config)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private fun parseConfigUri(uri: String): VpnConfig {
        // این باید URI های مختلف را پارس کند
        // این یک placeholder است
        return VpnConfig(
            name = "Imported Config",
            protocol = com.nimplus.data.VpnProtocol.VMESS,
            serverAddress = "example.com",
            serverPort = 443,
            configJson = "{}"
        )
    }
}
