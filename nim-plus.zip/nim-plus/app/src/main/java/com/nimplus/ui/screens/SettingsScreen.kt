package com.nimplus.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen() {
    var autoConnect by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(false) }
    var allowLan by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("تنظیمات") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Connection Settings
            SettingsSection(title = "اتصال") {
                SettingItem(
                    icon = Icons.Default.Autorenew,
                    title = "اتصال خودکار",
                    description = "اتصال خودکار به آخرین کانفیگ"
                ) {
                    Switch(
                        checked = autoConnect,
                        onCheckedChange = { autoConnect = it }
                    )
                }
                
                SettingItem(
                    icon = Icons.Default.Wifi,
                    title = "اجازه دسترسی LAN",
                    description = "دسترسی دستگاه‌های شبکه محلی"
                ) {
                    Switch(
                        checked = allowLan,
                        onCheckedChange = { allowLan = it }
                    )
                }
            }
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            // Appearance Settings
            SettingsSection(title = "ظاهر") {
                SettingItem(
                    icon = Icons.Default.DarkMode,
                    title = "حالت شب",
                    description = "فعال‌سازی تم تاریک"
                ) {
                    Switch(
                        checked = darkMode,
                        onCheckedChange = { darkMode = it }
                    )
                }
            }
            
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            
            // About
            SettingsSection(title = "درباره") {
                SettingItem(
                    icon = Icons.Default.Info,
                    title = "نسخه",
                    description = "1.0.0"
                ) {}
                
                SettingItem(
                    icon = Icons.Default.Code,
                    title = "متن‌باز",
                    description = "این برنامه متن‌باز است"
                ) {}
                
                SettingItem(
                    icon = Icons.Default.Favorite,
                    title = "حمایت از توسعه‌دهنده",
                    description = "با ستاره دادن در GitHub"
                ) {}
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        content()
    }
}

@Composable
fun SettingItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        trailing()
    }
}
