package com.nimplus.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vpn_configs")
data class VpnConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val protocol: VpnProtocol,
    val serverAddress: String,
    val serverPort: Int,
    val userId: String? = null,
    val password: String? = null,
    val encryption: String? = null,
    val network: String? = null,
    val alterId: Int? = null,
    val isActive: Boolean = false,
    val remarks: String? = null,
    val configJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastConnected: Long? = null,
    val uploadTraffic: Long = 0,
    val downloadTraffic: Long = 0
)

enum class VpnProtocol {
    VMESS,
    VLESS,
    SHADOWSOCKS,
    TROJAN,
    SOCKS,
    HTTP
}

data class ConnectionState(
    val isConnected: Boolean = false,
    val currentConfig: VpnConfig? = null,
    val duration: Long = 0,
    val uploadSpeed: Long = 0,
    val downloadSpeed: Long = 0,
    val uploadTraffic: Long = 0,
    val downloadTraffic: Long = 0,
    val ping: Int = 0,
    val errorMessage: String? = null
)

data class ServerInfo(
    val address: String,
    val port: Int,
    val ping: Int = -1,
    val isAvailable: Boolean = false
)
