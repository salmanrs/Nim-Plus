package com.nimplus.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.nimplus.R
import com.nimplus.data.VpnConfig
import com.nimplus.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@AndroidEntryPoint
class VpnService : VpnService() {
    
    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var currentConfig: VpnConfig? = null
    private var isRunning = false
    
    companion object {
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "nim_plus_vpn_channel"
        const val ACTION_CONNECT = "com.nimplus.action.CONNECT"
        const val ACTION_DISCONNECT = "com.nimplus.action.DISCONNECT"
        const val EXTRA_CONFIG = "config"
    }
    
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val config = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_CONFIG, VpnConfig::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_CONFIG)
                }
                config?.let { connect(it) }
            }
            ACTION_DISCONNECT -> {
                disconnect()
            }
        }
        return START_STICKY
    }
    
    private fun connect(config: VpnConfig) {
        if (isRunning) {
            disconnect()
        }
        
        currentConfig = config
        
        try {
            // Configure VPN
            val builder = Builder()
                .setSession("Nim Plus VPN")
                .addAddress("26.26.26.1", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("8.8.4.4")
                .setMtu(1500)
                .setBlocking(false)
            
            vpnInterface = builder.establish()
            isRunning = true
            
            // Show notification
            startForeground(NOTIFICATION_ID, createNotification(config.name, true))
            
            // Start VPN core service (این قسمت باید با V2Ray Core پیاده‌سازی شود)
            serviceScope.launch {
                runVpnCore(config)
            }
            
            // Monitor connection
            serviceScope.launch {
                monitorConnection()
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
            disconnect()
        }
    }
    
    private fun disconnect() {
        isRunning = false
        
        vpnInterface?.close()
        vpnInterface = null
        
        currentConfig = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    
    private suspend fun runVpnCore(config: VpnConfig) {
        // اینجا باید V2Ray Core راه‌اندازی شود
        // این یک placeholder است
        while (isActive && isRunning) {
            // Process VPN packets
            delay(1000)
        }
    }
    
    private suspend fun monitorConnection() {
        while (isActive && isRunning) {
            // Monitor traffic and update stats
            delay(1000)
        }
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VPN Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows VPN connection status"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(configName: String, isConnected: Boolean): android.app.Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        val title = if (isConnected) "متصل شده" else "در حال اتصال..."
        val text = "کانفیگ: $configName"
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }
    
    override fun onDestroy() {
        disconnect()
        serviceScope.cancel()
        super.onDestroy()
    }
}
