package com.nimplus.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

@Database(
    entities = [VpnConfig::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class NimPlusDatabase : RoomDatabase() {
    abstract fun vpnConfigDao(): VpnConfigDao
}

class Converters {
    @TypeConverter
    fun fromVpnProtocol(protocol: VpnProtocol): String {
        return protocol.name
    }

    @TypeConverter
    fun toVpnProtocol(value: String): VpnProtocol {
        return VpnProtocol.valueOf(value)
    }
}
