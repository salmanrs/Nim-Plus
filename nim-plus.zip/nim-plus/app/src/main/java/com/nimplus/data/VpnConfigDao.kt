package com.nimplus.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VpnConfigDao {
    
    @Query("SELECT * FROM vpn_configs ORDER BY lastConnected DESC")
    fun getAllConfigs(): Flow<List<VpnConfig>>
    
    @Query("SELECT * FROM vpn_configs WHERE id = :id")
    suspend fun getConfigById(id: Long): VpnConfig?
    
    @Query("SELECT * FROM vpn_configs WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveConfig(): VpnConfig?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: VpnConfig): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfigs(configs: List<VpnConfig>)
    
    @Update
    suspend fun updateConfig(config: VpnConfig)
    
    @Delete
    suspend fun deleteConfig(config: VpnConfig)
    
    @Query("DELETE FROM vpn_configs WHERE id = :id")
    suspend fun deleteConfigById(id: Long)
    
    @Query("UPDATE vpn_configs SET isActive = 0")
    suspend fun deactivateAllConfigs()
    
    @Query("UPDATE vpn_configs SET isActive = 1 WHERE id = :id")
    suspend fun setActiveConfig(id: Long)
    
    @Query("UPDATE vpn_configs SET uploadTraffic = :upload, downloadTraffic = :download WHERE id = :id")
    suspend fun updateTraffic(id: Long, upload: Long, download: Long)
    
    @Query("UPDATE vpn_configs SET lastConnected = :timestamp WHERE id = :id")
    suspend fun updateLastConnected(id: Long, timestamp: Long)
}
