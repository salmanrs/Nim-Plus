#!/bin/bash

# Gradle Wrapper Initialization Script
# This script will be run by GitHub Actions to setup Gradle Wrapper

echo "🔧 Initializing Gradle Wrapper..."

# Create gradle wrapper directory
mkdir -p gradle/wrapper

# Download gradle-wrapper.jar
echo "📥 Downloading gradle-wrapper.jar..."
curl -L -o gradle/wrapper/gradle-wrapper.jar \
  https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar

if [ $? -eq 0 ]; then
    echo "✅ gradle-wrapper.jar downloaded successfully"
else
    echo "⚠️  Failed to download gradle-wrapper.jar, GitHub Actions will handle it"
fi

# Make gradlew executable
chmod +x gradlew

echo "✅ Gradle Wrapper initialized!"
echo "🚀 Ready to build!"
